#include "Knight.h"


Knight::Knight() 
{

}

Knight::Knight(int hp) : Player(hp)
{

}

Knight::~Knight()
{

}

