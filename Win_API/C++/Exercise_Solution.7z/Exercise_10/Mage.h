#pragma once
#include "Player.h"

class Mage : public Player
{
public:
	Mage();
	Mage(int hp);
	~Mage();
};

