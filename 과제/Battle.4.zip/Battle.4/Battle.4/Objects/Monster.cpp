#include "pch.h"
#include "Creature.h"

#include "Monster.h"

Monster::Monster(int hp, int atk)
	:Creature(hp,atk)
{s
}

Monster::~Monster()
{
}
