#pragma once

#include "Objects/Player.h"

class Knight : public Player
{
public:

private:
};

