#pragma once
class Mage
{
};

