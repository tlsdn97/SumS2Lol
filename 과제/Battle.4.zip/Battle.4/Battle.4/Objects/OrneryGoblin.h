#pragma once
#include "Monster.h"

class OrneryGoblin : public Monster
{
public:
private:

};

