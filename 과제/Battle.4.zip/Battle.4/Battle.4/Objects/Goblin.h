#pragma once
class Goblin
{
};

