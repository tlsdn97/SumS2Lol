﻿#include "pch.h"

using namespace std;

#include <string>


int main()
{
	return 0;
}